# Equipo GCR.exe 

### Consideraciones:

- Se uso la ultima version de java 8 (update 241), PostgreSQL 12. Para trabajar los archivos, se uso IntelliJ IDEA;

### Instrucciones de ejecucion:

- Una vez importado el proyecto en un editor como IntelliJ IDEA o Eclipse, es importante antes de ejecutar, tener una BD de posgresql con una tabla del siguiente formato, ademas de editar el archivo de configuración de Spring  *application.propeties* configurando el nombre, puerto donde este la BD.


- Una vez ejecutado simplemente logearse con usuario = user , password = root 

### Actualizaciones:
- Se ha editado la pagina de logeo y funciona como tal (Y esta mas bonito 😔👌👌)
- Se agregó la historia de usuario explicada en el informe de entrega 3
- Se agregó headers en varias de las vistas.
xd